package eisya;

public class NurEisya {

  public static void main(String[] args)
{
	System.out.println("Nur Eisya Binti Hamalek");
}
}